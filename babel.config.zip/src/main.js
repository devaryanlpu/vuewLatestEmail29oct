import Vue from 'vue'
import App from './App.vue'

import './assets/jquery.min'
import './assets/bootstrap.bundle';
import './assets/sb-admin-2.min.css';
import './assets/datatables/jquery.dataTables.min.js';
import './assets/datatables/dataTables.bootstrap4.min.css';
import fontawesome from '@fortawesome/fontawesome-free/css/all.css'
import './assets/custom.css'
import 'bootstrap-vue/dist/bootstrap-vue.css'
import 'vue-multiselect/dist/vue-multiselect.min.css';
import BootstrapVue from 'bootstrap-vue'
import router from './router';
import Multiselect from 'vue-multiselect'
Vue.config.productionTip = false;


// register globally
Vue.component('multiselect', Multiselect)
Vue.use(fontawesome);
Vue.use(BootstrapVue)
Vue.config.productionTip = false
Vue.router = router;
new Vue({
  router,
  render: h => h(App),
}).$mount('#app')
