<template>
  <div class="device">
    <div class="row">
      <div class="col-lg-12">
        <div class="card shadow mb-1">
          <div class="card-header py-3 d-flex flex-row justify-content-between">
            <p class="m-0  text-primary">Messages (showing 1-2)</p>
    
            <button
              class="btn btn-primary w-10"
              @click="resetForm()"
              data-toggle="modal" data-target="#deviceModal"
            > <i class="far fa-paper-plane"></i> Send message</button>
       
          </div>
        <div class="card-body" style="padding:0;font-size:13px" id="no-more-tables" >
          <table class="table">
            <thead>
              <tr>
                <th>Device</th>
                <th>Status</th>
                <th>Type</th>
                <th>Phone</th>
                <th>Create date</th>
                <th></th>
              </tr>
            </thead>
          <tbody>
            <tr>
                <td scope="row" data-title="Device">eshte54 646</td>
                <td data-title="Status">
                  <span class="blink running">&nbsp;</span>
                    RUNNING</td>
                <td data-title="Type">dfgfdh</td>
                <td data-title="Phone">e464576457</td>
                <td data-title="Create date">yreyr654</td>
                <td> 
                  <div class="btn-group">
                      <button type="button" class="btn btn-default dropdown-toggle p-0 actions" data-toggle="dropdown">
                        <i class="fas fa-mobile-alt"></i>Actions <span class="caret"></span>
                      </button>
                        <ul class="dropdown-menu" role="menu">
                          <li><a href="javascript:void(0)" ><i class="fas fa-play"></i> Start</a></li>
                          <li><a href="javascript:void(0)"><i class="fas fa-stop"></i> Stop</a></li>
                          <li><a href="javascript:void(0)"><i class="fas fa-trash-alt"></i> Delete</a></li>
                      </ul>
                    </div>
                </td>
              </tr>
            </tbody>
          </table>
            <!-- <multiselect v-model="value" :options="options" :multiple="true" :taggable="true"></multiselect> -->
          </div>
        </div>
      </div>
    </div>
    



  </div>
</template>
<script>
export default {
  name: "messageHome",
    data () {
      return {
        value: null,
        options: ['list', 'of', 'options']
      }
    },
    methods: {
   
    },
    mounted(){
   
    }
};
</script>