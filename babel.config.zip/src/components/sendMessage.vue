<template>
  <div class="device">
    <div class="row">
      <div class="col-lg-12">
        <div class="card shadow mb-1">
          <div class="card-header py-3 d-flex flex-row justify-content-between">
            <h6 class="m-0 font-weight-bold text-primary"> Send Messages</h6>
          </div>
           <div class="card-body" style="padding:0;font-size:13px" id="no-more-tables" >
    <div class="row">
           <div class="col-lg-4 col-md-12 col-xs-12">
            
               <img src="../assets/images/message2.png" style="height:100px">
           </div>
     <div class="col-lg-8 col-md-12 col-xs-12">
        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                <label for="device">Device*</label>
                    <select class="form-control">
                        <option>Male</option>
                        <option>Female</option> 
                        </select>
                </div>
            </div>
        </div>
         <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                     <div class="custom-control custom-radio custom-control-inline">
      <input type="radio" class="custom-control-input" id="customRadio1" name="example1">
      <label class="custom-control-label" for="customRadio1" checked>Phone</label>
    </div>
                </div>
          
            </div>
             <div class="col-md-6">
                <div class="form-group">
                <label for="device">phone Number</label>
                  <input type="text" class="form-control" placeholder="+884456456">
                </div>
            </div>
        </div>
         <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                <label for="device">Message</label>
                 <textarea class="form-control" rows="5" id="comment"></textarea>
                </div>
            </div>
        </div>
    
     </div>

   </div>
</div>
          </div>
        </div>
      </div>
    </div>
    
</template>
<script>
export default {
  name: "sendMessage"
};
</script>