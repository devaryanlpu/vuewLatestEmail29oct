import Vue from "vue";
import Router from "vue-router";
import Master from "./layouts/Master";
import MessageLayout from './layouts/MessageLayout';
import Home from './components/home';
import MessageHome from './components/messageHome';
import SendMessage from './components/sendMessage';

Vue.use(Router);

const router = new Router({
    mode: "history",
    base: process.env.BASE_URL,
    routes: [
        {
            path: "/",
            redirect: "dashboard"
        },
        {
            path: "/dashboard",
            component: Master,
            children: [
                {
                    path: "home",
                    name: "home",
                    component: Home
                },
                {
                    path: "messages",
                    name: "MessageLayout",
                    component: MessageLayout,
                    children: [
                        {
                            path: "",
                            name: "messageHome",
                            component: MessageHome
                        },
                        {
                            path: "sendMessage",
                            name: "sendMessage",
                            component: SendMessage
                        }
                    ]
               
                }
             
            ]
        }
    ]
});


export default router;
